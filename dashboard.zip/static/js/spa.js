// SPA Controller for GitHub Issues Dashboard
// Handles all client-side state management, routing, and data loading

class DashboardSPA {
    constructor() {
        this.state = {
            dataType: 'issues',
            showState: 'open',
            selectedRepo: '',
            repositories: [], // Repos with data
            allRepositories: [], // All repos including those with 0 records
            sdkCounts: {},
            syncStats: {},
            isLoading: false,
            cache: new Map()
        };
        
        this.isInitializing = false; // Flag to prevent URL updates during initialization
        
        this.init();
    }
    
    // Get display name from repository name (fallback only)
    getDisplayName(repoName) {
        return repoName.split('/').pop(); // Get the part after the last slash
    }
    
    init() {
        // Initialize the SPA
        this.setupEventListeners();
        this.setupRouter();
        this.loadInitialState();
        this.applyInitialState(); // Apply the state using the same functions as menu buttons
        // Note: applyInitialState will trigger data loading through setDataType/setShowState calls
    }
    
    setupEventListeners() {
        // Data type toggle buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('.btn-toggle-data-type')) {
                const dataType = e.target.id === 'issues-toggle' ? 'issues' : 'prs';
                this.setDataType(dataType);
            }
        });

        // Global state filter buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('.btn-state-filter') || e.target.closest('.btn-state-filter')) {
                e.preventDefault();
                const button = e.target.matches('.btn-state-filter') ? e.target : e.target.closest('.btn-state-filter');
                const newState = button.getAttribute('data-state');
                console.log('Global state filter clicked:', newState);
                this.setShowState(newState);
                this.updateGlobalStateToggle();
            }
        });

        // Open details dialog only when clicking the Title link
        document.addEventListener('click', (e) => {
            const titleLink = e.target.closest('.open-modal');
            if (titleLink) {
                e.preventDefault();
                e.stopPropagation();
                const row = titleLink.closest('tr');
                if (row && typeof openIssueModalFromData === 'function') {
                    openIssueModalFromData(row);
                }
            }
        });
        
        // Repository navigation
        document.addEventListener('click', (e) => {
            if (e.target.matches('.nav-link[data-repo]')) {
                e.preventDefault();
                const repo = e.target.getAttribute('data-repo');
                this.setSelectedRepo(repo);
            }
        });
        
        // State filter buttons (when they're added dynamically)
        document.addEventListener('click', (e) => {
            if (e.target.matches('.state-filter-btn')) {
                e.preventDefault();
                const state = e.target.getAttribute('data-state');
                this.setShowState(state);
            }
        });
        
        // Clear repository selection
        document.addEventListener('click', (e) => {
            if (e.target.matches('.clear-repo-btn')) {
                e.preventDefault();
                this.setSelectedRepo('');
            }
        });
        
        // Dropdown menu item clicks (for repository selection)
        document.addEventListener('click', (e) => {
            // Handle dropdown items with onclick handlers
            if (e.target.matches('.dropdown-item[onclick*="selectRepository"]')) {
                e.preventDefault();
                console.log('Dropdown item clicked via onclick handler:', e.target);
                // Extract repository name from onclick attribute
                const onclickAttr = e.target.getAttribute('onclick');
                const match = onclickAttr.match(/selectRepository\('([^']+)'\)/);
                if (match) {
                    const repoName = match[1];
                    console.log('Selecting repository from dropdown:', repoName);
                    this.selectRepository(repoName);
                }
                return false;
            }
            
            // Also handle dropdown items without onclick (fallback)
            if (e.target.matches('.dropdown-item') && e.target.textContent.trim() !== '') {
                const dropdownMenu = e.target.closest('.dropdown-menu');
                if (dropdownMenu && dropdownMenu.id.includes('-dropdown-menu')) {
                    console.log('Dropdown item clicked (fallback):', e.target.textContent);
                    e.preventDefault();
                    // This is a fallback - the onclick handler should handle it
                }
            }
        });
        
        // Browser back/forward buttons
        window.addEventListener('popstate', (e) => {
            this.handlePopState(e);
        });
    }
    
    setupRouter() {
        // Setup client-side routing without page refresh
        // Don't call updateURLFromState() here as it will overwrite URL parameters
    }
    
    loadInitialState() {
        // Load initial state from URL parameters and apply them using the same
        // functions that menu buttons use to ensure consistency
        const urlParams = new URLSearchParams(window.location.search);
        
        const dataType = urlParams.get('type') || 'issues';
        const showState = urlParams.get('state') || 'open';
        const selectedRepo = urlParams.get('repo') || '';
        
        // Validate and set data type using the same function as menu buttons
        if (['issues', 'prs'].includes(dataType)) {
            this.state.dataType = dataType; // Set directly since setDataType would reload data
        } else {
            this.state.dataType = 'issues';
        }
        
        // Validate and set show state using the same function as menu buttons  
        if (['open', 'closed', 'all'].includes(showState)) {
            this.state.showState = showState; // Set directly since setShowState would reload data
        } else {
            this.state.showState = 'open';
        }
        
        // Set selected repo using the same function as menu buttons
        if (selectedRepo) {
            this.state.selectedRepo = selectedRepo; // Set directly since setSelectedRepo would update URL
        }
        
        console.log('Initial state loaded from URL:', {
            dataType: this.state.dataType,
            showState: this.state.showState,
            selectedRepo: this.state.selectedRepo
        });
    }
    
    applyInitialState() {
        // Load repositories for navbar first
        console.log('Loading repositories for navbar');
        
        // Load repositories for navbar
        this.loadRepositories().then(() => {
            console.log('Repositories loaded for navbar');
            
            // Always load dashboard data to get counts for overview cards
            // but control whether to display the table via updateContentFromData
            console.log('Loading dashboard data for overview counts');
            this.state.dataType = this.state.dataType || 'issues';
            this.updateURL();
            this.updateDataTypeToggle();
            this.updateGlobalStateToggle();
            this.loadDashboardData(); // Always load data for counts
        }).catch(error => {
            console.error('Error loading repositories:', error);
            this.showWelcomeMessage();
        });
    }
    
    showWelcomeMessage() {
        const contentContainer = document.getElementById('repositories-container');
        if (contentContainer) {
            contentContainer.innerHTML = `
                <div class="text-center mt-5">
                    <h2>Welcome to Azure Monitor TelReach GitHub Dashboard</h2>
                    <p class="lead">Select a category from the navigation bar above to view issues or pull requests.</p>
                    <div class="mt-4">
                        <button class="btn btn-primary mr-2" onclick="dashboardSPA.setDataType('issues')" id="welcome-issues-btn">
                            <i class="fas fa-bug"></i> View Issues
                        </button>
                        <button class="btn btn-success" onclick="dashboardSPA.setDataType('prs')" id="welcome-prs-btn">
                            <i class="fas fa-code-branch"></i> View Pull Requests
                        </button>
                    </div>
                </div>
            `;
        }
        
        // Update the button states
        this.updateDataTypeToggle();
        this.updateGlobalStateToggle();
    }
    
    async loadRepositoriesAndData() {
        try {
            await this.loadRepositories();
        } catch (error) {
            console.error('Error loading repositories:', error);
        }
        
        // Then load the actual data
        this.loadDashboardData();
    }
    
    async loadRepositories() {
        try {
            // First load repositories for navbar
            const repositoriesResponse = await fetch('http://localhost:8000/api/repositories');
            if (repositoriesResponse.ok) {
                const repositoriesData = await repositoriesResponse.json();
                const repositories = repositoriesData.repositories || [];
                
                // Hide any existing API error messages
                this.hideApiError();
                
                // Process repositories using the existing logic
                this.updateUIFromData({ repositories: repositories });
                
                // Build navbar from repositories
                this.buildNavbarFromRepositories(repositories);
            } else {
                throw new Error(`HTTP ${repositoriesResponse.status}`);
            }
        } catch (error) {
            console.error('Error loading repositories:', error);
            this.showApiError('Unable to connect to the sync service API. Please ensure the sync service is running on port 8000.');
            throw new Error(`Failed to load repositories: ${error.message}`);
        }
    }
    
    async loadDashboardData() {
        this.setLoading(true);
        
        try {
            const cacheKey = `${this.state.dataType}-${this.state.showState}-${this.state.selectedRepo}`;
            
            // Check cache first
            if (this.state.cache.has(cacheKey)) {
                const cachedData = this.state.cache.get(cacheKey);
                this.hideApiError(); // Hide error banner since we have cached data
                this.updateContentFromData(cachedData);
                this.setLoading(false);
                return;
            }

            // Load repositories first if we don't have them
            if (!this.state.repositories || this.state.repositories.length === 0) {
                await this.loadRepositories();
            }
            
            // Build API URL for issues or PRs
            let apiUrl = '';
            if (this.state.dataType === 'issues') {
                apiUrl = `http://localhost:8000/api/issues`;
            } else if (this.state.dataType === 'prs') {
                apiUrl = `http://localhost:8000/api/pull_requests`;
            } else {
                throw new Error('Invalid data type');
            }
            
            // Add query parameters
            const params = new URLSearchParams();
            // Note: Repository filtering on server side causes 500 errors
            // We'll filter client-side instead in updateContentFromData
            if (this.state.showState !== 'all') {
                params.append('state', this.state.showState);
            }
            // No limit - fetch all items
            
            if (params.toString()) {
                apiUrl += '?' + params.toString();
            }

            const response = await fetch(apiUrl, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const contentData = await response.json();
            
            // Hide any existing API error since we successfully loaded data
            this.hideApiError();
            
            // Cache the content data
            this.state.cache.set(cacheKey, contentData);
            
            // Update content area with issues/PRs
            this.updateContentFromData(contentData);
            
        } catch (error) {
            console.error('Error loading dashboard data:', error);
            
            // Check if this is likely a network/API error
            if (error.message.includes('fetch') || error.message.includes('NetworkError') || 
                error.message.includes('Failed to fetch') || error.message.includes('HTTP error')) {
                this.showApiError('Unable to connect to the sync service API. Please ensure the sync service is running on port 8000.');
            } else {
                this.showError(`Failed to load dashboard data: ${error.message}`);
            }
        } finally {
            this.setLoading(false);
        }
    }
    
    updateUIFromData(data) {
        // Use the new schema from sync service
        const repositories = Array.isArray(data.repositories) ? data.repositories : [];

        console.log('Repositories from sync service API:', repositories);

        // Convert to objects expected by the rest of the UI
        const processedRepos = repositories.map(repoData => {
            // Add safety checks for undefined data
            if (!repoData || !repoData.repo) {
                console.warn('Invalid repository data:', repoData);
                return null;
            }
            
            console.log(`Repository: ${repoData.repo} -> Category: ${repoData.main_category} (${repoData.classification})`);
            
            return {
                id: repoData.repo.replace(/[^a-zA-Z0-9]/g, '-'),
                name: repoData.repo,
                display_name: repoData.display_name || repoData.repo.split('/').pop(),
                sdk_type: repoData.main_category || 'other',
                main_category: repoData.main_category || 'other',
                classification: repoData.classification || 'unknown',
                priority: repoData.priority || 1,
                count: 0,
                items: []
            };
        }).filter(repo => repo !== null); // Remove any null entries

        console.log('Processed repositories:', processedRepos);

        this.state.repositories = processedRepos;
        this.state.allRepositories = repositories
            .filter(r => r && r.repo) // Filter out undefined/null entries and those without repo property
            .map(r => r.repo); // Extract just repo names for compatibility
        this.state.sdkCounts = {};
        this.state.syncStats = {};

        // Update UI elements
        this.updateDataTypeToggle();
        this.updateGlobalStateToggle();
        this.updateRepositorySections();
        this.updateNavigation();
        this.updateVisibility();
    }
    
    buildNavbarFromRepositories(repositories) {
        // Group repositories by main category for navbar
        const categoriesMap = new Map();
        
        repositories.forEach(repo => {
            const category = repo.main_category;
            if (!categoriesMap.has(category)) {
                categoriesMap.set(category, {
                    repositories: [],
                    count: 0
                });
            }
            
            categoriesMap.get(category).repositories.push({
                id: repo.repo.replace(/[^a-zA-Z0-9]/g, '-'),
                name: repo.repo,
                display_name: repo.display_name,
                count: 0 // Will be updated when content is loaded
            });
        });
        
        // Build navbar dynamically
        this.buildDynamicNavbar(categoriesMap);
    }
    
    updateContentFromData(contentData) {
        // Extract the actual data array from the sync service response
        let dataArray = [];
        if (contentData.issues) {
            dataArray = contentData.issues; // For /api/issues
        } else if (contentData.pull_requests || contentData.prs) {
            dataArray = contentData.pull_requests || contentData.prs; // For /api/pull_requests
        } else if (Array.isArray(contentData)) {
            dataArray = contentData; // Fallback if it's already an array
        }
        
        console.log(`Loaded ${dataArray.length} ${this.state.dataType}`);
        
        // Always update repository counts for overview cards
        this.updateRepositoryCountsFromData(dataArray);
        
        // Update the repository count display
        this.updateRepositoryCountDisplay(dataArray);
        
        // Only display the table if a specific repository is selected
        if (this.state.selectedRepo && this.state.selectedRepo !== 'all' && this.state.selectedRepo !== '') {
            console.log('Displaying table for selected repository:', this.state.selectedRepo);
            this.displayDataTable(dataArray);
        } else {
            console.log('No specific repository selected, hiding table and showing overview only');
            // Clear the table content but keep the overview cards
            const contentContainer = document.getElementById('repositories-container');
            if (contentContainer) {
                contentContainer.innerHTML = '';
            }
        }
    }
    
    displayDataTable(dataArray) {
        const contentContainer = document.getElementById('repositories-container');
        if (!contentContainer) return;
        
        // Filter data for selected repository if one is selected
        let filteredData = dataArray;
        if (this.state.selectedRepo && this.state.selectedRepo !== 'all' && this.state.selectedRepo !== '') {
            filteredData = dataArray.filter(item => {
                const repoName = item.repo || item.repository;
                return repoName === this.state.selectedRepo;
            });
            console.log(`Filtered ${dataArray.length} items to ${filteredData.length} for repository: ${this.state.selectedRepo}`);
        }
        
        // Get repository info for display
        const selectedRepoObj = this.state.repositories.find(r => r.name === this.state.selectedRepo);
        const repoDisplayName = selectedRepoObj ? selectedRepoObj.display_name : this.state.selectedRepo;
        const repoId = selectedRepoObj ? selectedRepoObj.id : this.state.selectedRepo.replace(/[^a-zA-Z0-9]/g, '-');
        
        const dataTypeLabel = this.state.dataType === 'issues' ? 'Issues' : 'Pull Requests';
        const isPRs = this.state.dataType === 'prs';
        
        // Generate state filter buttons
        const stateFilters = `
            <div class="state-filters mb-3">
                <div class="btn-group btn-group-sm" role="group">
                    <button type="button" class="btn state-filter-btn ${this.state.showState === 'open' ? 'btn-primary' : 'btn-outline-primary'}" data-state="open">
                        <i class="fas fa-exclamation-circle"></i> Open
                    </button>
                    <button type="button" class="btn state-filter-btn ${this.state.showState === 'closed' ? 'btn-success' : 'btn-outline-success'}" data-state="closed">
                        <i class="fas fa-check-circle"></i> Closed
                    </button>
                    <button type="button" class="btn state-filter-btn ${this.state.showState === 'all' ? 'btn-secondary' : 'btn-outline-secondary'}" data-state="all">
                        <i class="fas fa-list"></i> All
                    </button>
                </div>
            </div>
        `;
        
        // Generate search controls
        const searchControls = `
            <div class="controls mb-3">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                    </div>
                    <input type="text" class="form-control search-box" 
                           placeholder="Search ${dataTypeLabel.toLowerCase()}..." 
                           oninput="filterTable('${repoId}', this.value)"
                           id="search-${repoId}">
                </div>
            </div>
        `;
        
        // Generate pagination controls
        const paginationControls = `
            <div class="pagination-container mt-3" id="pagination-${repoId}">
                <div class="d-flex justify-content-between align-items-center">
                    <div id="page-info-${repoId}" class="text-muted"></div>
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-primary btn-sm" 
                                id="prev-btn-${repoId}" onclick="prevPage('${repoId}')">
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                        <button type="button" class="btn btn-outline-primary btn-sm" 
                                id="next-btn-${repoId}" onclick="nextPage('${repoId}')">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                <div class="mt-2 text-center">
                    <small class="text-muted">
                        Page <input type="number" id="page-input-${repoId}" 
                                   class="form-control d-inline-block" 
                                   style="width: 70px; height: 25px; padding: 2px 5px; font-size: 12px;"
                                   min="1" onchange="goToPage('${repoId}', this.value)"> 
                        of <span id="page-counter-${repoId}">1</span>
                    </small>
                </div>
            </div>
        `;
        
        // Dynamic table headers with sorting
        const tableHeaders = isPRs ? `
            <tr>
                <th onclick="sortTable('${repoId}', 'number')" class="sortable" data-column="number"># <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repoId}', 'title')" class="sortable" data-column="title">Title <i class="fas fa-sort sort-icon"></i></th>
                <th>Labels</th>
                <th>Author</th>
                <th>Reviewers</th>
                <th>Assignees</th>
                <th onclick="sortTable('${repoId}', 'created')" class="sortable" data-column="created">Created <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repoId}', 'updated')" class="sortable" data-column="updated">Updated <i class="fas fa-sort sort-icon"></i></th>
            </tr>` : `
            <tr>
                <th onclick="sortTable('${repoId}', 'number')" class="sortable" data-column="number"># <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repoId}', 'title')" class="sortable" data-column="title">Title <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repoId}', 'labels')" class="sortable" data-column="labels">Labels <i class="fas fa-sort sort-icon"></i></th>
                <th>Opened by</th>
                <th onclick="sortTable('${repoId}', 'assignee')" class="sortable" data-column="assignee">Assignee <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repoId}', 'created')" class="sortable" data-column="created">Created <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repoId}', 'updated')" class="sortable" data-column="updated">Updated <i class="fas fa-sort sort-icon"></i></th>
            </tr>`;
        
        // Generate table rows
        let tableRows = '';
        filteredData.forEach(item => {
            if (isPRs) {
                tableRows += this.generatePRRow(item);
            } else {
                tableRows += this.generateIssueRow(item);
            }
        });
        
        // Create complete table HTML with navigation
        const tableHtml = `
            <div class="repository-section repo-section spa-fade-in mt-4" id="repo-${repoId}" data-repo="${this.state.selectedRepo}">
                <div class="repo-header">
                    <h2 class="repo-title">
                        <a href="https://github.com/${this.state.selectedRepo}" target="_blank">
                            <i class="fab fa-github"></i>
                            ${repoDisplayName}
                        </a>
                        <span class="issue-count badge badge-primary ml-2">${filteredData.length}</span>
                    </h2>
                </div>
                
                ${stateFilters}
                ${searchControls}
                
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-sm issues-table ${isPRs ? 'prs' : ''}" id="table-${repoId}">
                        <thead class="thead-light">
                            ${tableHeaders}
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>
                </div>
                
                ${paginationControls}
            </div>
        `;
        
        contentContainer.innerHTML = tableHtml;
        
        // Initialize table functionality
        this.initializeTableForRepository(repoId, filteredData);
        
        // Set up state filter event handlers
        const stateFilterBtns = contentContainer.querySelectorAll('.state-filter-btn');
        stateFilterBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                // Use currentTarget instead of target to ensure we get the button element
                const newState = e.currentTarget.getAttribute('data-state');
                console.log('State filter clicked:', newState);
                this.setShowState(newState);
                this.loadData(); // Reload data with new state filter
            });
        });
    }
    
    updateRepositoryCountsFromData(dataArray) {
        // Reset all repository counts
        if (this.state.repositories) {
            this.state.repositories.forEach(repo => {
                repo.count = 0;
                repo.items = [];
            });
        }
        
        // Count items by repository
        console.log('Counting items for', dataArray.length, 'items');
        const categoryCounts = new Map();
        
        dataArray.forEach(item => {
            // The API returns 'repo' field, not 'repository'
            const repoName = item.repo || item.repository; 
            
            if (repoName && this.state.repositories) {
                const repo = this.state.repositories.find(r => r.name === repoName);
                if (repo) {
                    repo.count++;
                    repo.items.push(item);
                    
                    // Update category count
                    const category = repo.main_category || 'other';
                    categoryCounts.set(category, (categoryCounts.get(category) || 0) + 1);
                }
            }
        });
        
        console.log('Updated repository counts');
        
        // Update the UI to reflect the new counts
        this.updateRepositoryCountsInUI();
        
        // Update the overview stats cards
        this.updateIntroStats();
        
        // Rebuild the dynamic navbar to update dropdown counts
        const categoriesMap = new Map();
        if (this.state.repositories) {
            this.state.repositories.forEach(repo => {
                const category = repo.main_category || 'other';
                if (!categoriesMap.has(category)) {
                    categoriesMap.set(category, { count: 0, repositories: [] });
                }
                const categoryData = categoriesMap.get(category);
                categoryData.count += repo.count || 0;
                categoryData.repositories.push(repo);
            });
        }
        this.buildDynamicNavbar(categoriesMap);
        
        // Don't automatically show repository sections - only show the table we just created
        // this.updateRepositorySections(); // Removed this line
    }
    
    updateRepositoryCountDisplay(dataArray) {
        const countDisplay = document.getElementById('repo-count-display');
        const repoNameDisplay = document.getElementById('repo-name-display');
        const countNumberDisplay = document.getElementById('count-display');
        const typeDisplay = document.getElementById('type-display');
        
        if (!countDisplay || !repoNameDisplay || !countNumberDisplay || !typeDisplay) {
            return;
        }
        
        if (this.state.selectedRepo && this.state.selectedRepo !== 'all' && this.state.selectedRepo !== '') {
            // Filter data for the selected repository
            const filteredData = dataArray.filter(item => {
                const repoName = item.repo || item.repository;
                return repoName === this.state.selectedRepo;
            });
            
            // Get repository display name
            const selectedRepoObj = this.state.repositories ? 
                this.state.repositories.find(r => r.name === this.state.selectedRepo) : null;
            const repoDisplayName = selectedRepoObj ? selectedRepoObj.display_name : this.state.selectedRepo;
            
            // Update display
            repoNameDisplay.textContent = repoDisplayName || this.state.selectedRepo;
            countNumberDisplay.textContent = filteredData.length;
            typeDisplay.textContent = this.state.dataType === 'issues' ? 'issues' : 'pull requests';
            
            // Show the count display
            countDisplay.style.display = 'block';
        } else {
            // Hide the count display when no specific repository is selected
            countDisplay.style.display = 'none';
        }
    }
    
    updateRepositoryCountsInUI() {
        // Update counts in any UI elements that display repository counts
        // This could include cards, badges, or other UI components
        if (this.state.repositories) {
            this.state.repositories.forEach(repo => {
                // Update any UI elements with repository counts
                const countElements = document.querySelectorAll(`[data-repo-count="${repo.name}"]`);
                countElements.forEach(element => {
                    element.textContent = repo.count;
                });
            });
        }
    }

    updateNavbarCounts() {
        // Update the counts in navbar dropdown menus
        this.state.repositories.forEach(repo => {
            const countElement = document.querySelector(`#navbar-${repo.id}-count`);
            if (countElement) {
                countElement.textContent = repo.count;
            }
        });
        
        // Update category totals in navbar
        const categoriesMap = new Map();
        this.state.repositories.forEach(repo => {
            const category = repo.main_category;
            if (!categoriesMap.has(category)) {
                categoriesMap.set(category, 0);
            }
            categoriesMap.set(category, categoriesMap.get(category) + repo.count);
        });
        
        // Update category counts in navbar
        categoriesMap.forEach((count, category) => {
            const categoryCountElement = document.querySelector(`#navbar-${category}-count`);
            if (categoryCountElement) {
                categoryCountElement.textContent = count;
            }
        });
    }
    
    processRepositoryData(data) {
    // No longer used: always return empty array
    return [];
    }
    
    updateDataTypeToggle() {
        const issuesToggle = document.getElementById('issues-toggle');
        const prsToggle = document.getElementById('prs-toggle');
        
        if (issuesToggle && prsToggle) {
            // Update active states
            if (this.state.dataType === 'issues') {
                issuesToggle.className = 'btn btn-toggle-data-type btn-primary active';
                prsToggle.className = 'btn btn-toggle-data-type btn-outline-primary';
            } else {
                issuesToggle.className = 'btn btn-toggle-data-type btn-outline-primary';
                prsToggle.className = 'btn btn-toggle-data-type btn-primary active';
            }
        }
    }
    
    updateGlobalStateToggle() {
        const openToggle = document.getElementById('open-toggle');
        const closedToggle = document.getElementById('closed-toggle');
        const allToggle = document.getElementById('all-toggle');
        
        if (openToggle && closedToggle && allToggle) {
            // Reset all buttons
            openToggle.className = 'btn btn-state-filter btn-outline-primary';
            closedToggle.className = 'btn btn-state-filter btn-outline-success';
            allToggle.className = 'btn btn-state-filter btn-outline-secondary';
            
            // Set active state
            if (this.state.showState === 'open') {
                openToggle.className = 'btn btn-state-filter btn-primary active';
            } else if (this.state.showState === 'closed') {
                closedToggle.className = 'btn btn-state-filter btn-success active';
            } else if (this.state.showState === 'all') {
                allToggle.className = 'btn btn-state-filter btn-secondary active';
            }
        }
    }
    
    updateIntroStats() {
        // Calculate counts by category from repository data
        const categoryCounts = new Map();
        let totalCount = 0;
        
        if (this.state.repositories) {
            this.state.repositories.forEach(repo => {
                const count = repo.count || 0;
                const category = repo.main_category || 'other';
                
                totalCount += count;
                categoryCounts.set(category, (categoryCounts.get(category) || 0) + count);
            });
        }
        
        // Category display configuration
        const categoryConfig = {
            'nodejs': { icon: 'fab fa-node-js', label: 'Node.js', color: 'text-success' },
            'python': { icon: 'fab fa-python', label: 'Python', color: 'text-info' },
            'dotnet': { icon: 'fab fa-microsoft', label: '.NET', color: 'text-primary' },
            'browser': { icon: 'fab fa-js-square', label: 'Browser JS', color: 'text-warning' },
            'javascript': { icon: 'fab fa-js-square', label: 'Browser JS', color: 'text-warning' },
            'java': { icon: 'fab fa-java', label: 'Java', color: 'text-danger' },
            'react': { icon: 'fab fa-react', label: 'React', color: 'text-info' },
            'other': { icon: 'fas fa-code', label: 'Other', color: 'text-secondary' }
        };
        
        // Get the stats grid container
        const statsGrid = document.getElementById('dynamic-stats-grid');
        if (!statsGrid) return;
        
        // Clear existing content
        statsGrid.innerHTML = '';
        
        // Create stat items for each category that has data
        const sortedCategories = Array.from(categoryCounts.entries())
            .sort((a, b) => b[1] - a[1]); // Sort by count descending
        
        sortedCategories.forEach(([category, count]) => {
            const config = categoryConfig[category] || categoryConfig['other'];
            const dataType = this.state.dataType === 'issues' ? 'Issues' : 'Pull Requests';
            
            const statItem = document.createElement('div');
            statItem.className = 'stat-item';
            statItem.innerHTML = `
                <span class="stat-number ${config.color}">${count}</span>
                <span class="stat-label">${config.label} ${dataType}</span>
            `;
            
            statsGrid.appendChild(statItem);
        });
        
        // Always add total at the end
        const totalItem = document.createElement('div');
        totalItem.className = 'stat-item';
        const dataType = this.state.dataType === 'issues' ? 'Issues' : 'Pull Requests';
        totalItem.innerHTML = `
            <span class="stat-number text-dark"><strong>${totalCount}</strong></span>
            <span class="stat-label"><strong>Total ${dataType}</strong></span>
        `;
        
        statsGrid.appendChild(totalItem);
    }
    
    updateRepositorySections() {
        // Find the main container for repository sections
        const mainContainer = document.querySelector('.main-container');
        if (!mainContainer) return;
        
        // Remove existing repository sections but keep intro page and empty state
        const existingSections = mainContainer.querySelectorAll('.repository-section');
        existingSections.forEach(section => section.remove());
        
        // Find the repositories container or create it
        let repositoriesContainer = document.getElementById('repositories-container');
        if (!repositoriesContainer) {
            repositoriesContainer = document.createElement('div');
            repositoriesContainer.id = 'repositories-container';
            mainContainer.appendChild(repositoriesContainer);
        }
        
        // Clear the container
        repositoriesContainer.innerHTML = '';
        
        // Add new repository sections
        this.state.repositories.forEach((repo, index) => {
            const sectionHTML = this.generateRepositorySection(repo, index === 0);
            repositoriesContainer.insertAdjacentHTML('beforeend', sectionHTML);
        });
        
        // Reinitialize any JavaScript functionality for the new sections
        this.initializeRepositorySections();
    }
    
    generateRepositorySection(repo, isFirst) {
        if (repo.count === 0) {
            return this.generateEmptyRepositorySection(repo);
        }
        
        const dataTypeLabel = this.state.dataType === 'prs' ? 'Pull Requests' : 'Issues';
        const dataTypeLabelSingular = this.state.dataType === 'prs' ? 'Pull Request' : 'Issue';
        
        let itemRows = '';
        repo.items.forEach(item => {
            itemRows += this.generateItemRow(item);
        });
        
        // Generate state filter buttons
        const stateFilters = `
            <div class="state-filters mb-3">
                <div class="btn-group btn-group-sm" role="group">
                    <button type="button" class="btn state-filter-btn ${this.state.showState === 'open' ? 'btn-primary' : 'btn-outline-primary'}" data-state="open">
                        <i class="fas fa-exclamation-circle"></i> Open
                    </button>
                    <button type="button" class="btn state-filter-btn ${this.state.showState === 'closed' ? 'btn-success' : 'btn-outline-success'}" data-state="closed">
                        <i class="fas fa-check-circle"></i> Closed
                    </button>
                    <button type="button" class="btn state-filter-btn ${this.state.showState === 'all' ? 'btn-secondary' : 'btn-outline-secondary'}" data-state="all">
                        <i class="fas fa-list"></i> All
                    </button>
                </div>
            </div>
        `;
        
    // Generate search/filter controls (expected by dashboard.js)
        const searchControls = `
            <div class="controls mb-3">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                    </div>
                    <input type="text" class="form-control search-box" 
                           placeholder="Search ${dataTypeLabel.toLowerCase()}..." 
                           oninput="filterTable('${repo.id}', this.value)"
                           id="search-${repo.id}">
                </div>
            </div>
        `;
        
        // Generate pagination controls (expected by dashboard.js)
        const paginationControls = `
            <div class="pagination-container mt-3" id="pagination-${repo.id}" style="display: none;">
                <div class="d-flex justify-content-between align-items-center">
                    <div id="page-info-${repo.id}" class="text-muted"></div>
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-primary btn-sm" 
                                id="prev-btn-${repo.id}" onclick="prevPage('${repo.id}')">
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                        <button type="button" class="btn btn-outline-primary btn-sm" 
                                id="next-btn-${repo.id}" onclick="nextPage('${repo.id}')">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                <div class="mt-2 text-center">
                    <small class="text-muted">
                        Page <input type="number" id="page-input-${repo.id}" 
                                   class="form-control d-inline-block" 
                                   style="width: 70px; height: 25px; padding: 2px 5px; font-size: 12px;"
                                   min="1" onchange="goToPage('${repo.id}', this.value)"> 
                        of <span id="page-counter-${repo.id}">1</span>
                    </small>
                </div>
            </div>
        `;
        
        // Dynamic table headers based on data type
        const isPRs = this.state.dataType === 'prs' || (repo.items[0] && repo.items[0].item_type === 'pr');
    const tableHeaders = isPRs ? `
                        <tr>
                <th onclick="sortTable('${repo.id}', 'number')" class="sortable" data-column="number"># <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repo.id}', 'title')" class="sortable" data-column="title">Title <i class="fas fa-sort sort-icon"></i></th>
                <th>Labels</th>
                <th>Author</th>
                <th>Reviewers</th>
                <th>Assignees</th>
                <th onclick="sortTable('${repo.id}', 'created')" class="sortable" data-column="created">Created <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repo.id}', 'updated')" class="sortable" data-column="updated">Updated <i class="fas fa-sort sort-icon"></i></th>
                        </tr>` : `
                        <tr>
                <th onclick="sortTable('${repo.id}', 'number')" class="sortable" data-column="number"># <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repo.id}', 'title')" class="sortable" data-column="title">Title <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repo.id}', 'labels')" class="sortable" data-column="labels">Labels <i class="fas fa-sort sort-icon"></i></th>
                <th>Opened by</th>
                <th onclick="sortTable('${repo.id}', 'assignee')" class="sortable" data-column="assignee">Assignee <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repo.id}', 'created')" class="sortable" data-column="created">Created <i class="fas fa-sort sort-icon"></i></th>
                <th onclick="sortTable('${repo.id}', 'updated')" class="sortable" data-column="updated">Updated <i class="fas fa-sort sort-icon"></i></th>
                        </tr>`;

        return `
        <div class="repository-section repo-section spa-fade-in" id="repo-${repo.id}" data-repo="${repo.name}">
            <div class="repo-header">
                <h2 class="repo-title">
                    <a href="https://github.com/${repo.name}" target="_blank">
                        <i class="fab fa-github"></i>
                        ${repo.display_name}
                    </a>
                    <span class="issue-count badge badge-primary ml-2">${repo.count}</span>
                </h2>
            </div>
            
            ${stateFilters}
            ${searchControls}
            
            <div class="table-responsive">
                <table class="table table-striped table-hover table-sm issues-table ${isPRs ? 'prs' : ''}" id="table-${repo.id}">
                    <thead class="thead-light">
                        ${tableHeaders}
                    </thead>
                    <tbody>
                        ${itemRows}
                    </tbody>
                </table>
            </div>
            
            ${paginationControls}
        </div>
        `;
    }
    
    generateEmptyRepositorySection(repo) {
        const dataTypeLabel = this.state.dataType === 'prs' ? 'pull requests' : 'issues';
        const stateLabel = this.state.showState === 'all' ? '' : ` ${this.state.showState}`;
        
        return `
        <div class="repository-section empty" id="section-${repo.id}" data-repo="${repo.name}">
            <div class="repo-header">
                <h2 class="repo-title">
                    <a href="https://github.com/${repo.name}" target="_blank">
                        <i class="fab fa-github"></i>
                        ${repo.display_name}
                    </a>
                </h2>
            </div>
            <div class="empty-repo-state">
                <i class="fas fa-check-circle text-success"></i>
                <p>No${stateLabel} ${dataTypeLabel} found</p>
            </div>
        </div>
        `;
    }
    
    generateItemRow(item) {
        const isPR = (this.state.dataType === 'prs') || (item.item_type === 'pr');
        if (isPR) {
            return this.generatePRRow(item);
        }
        return this.generateIssueRow(item);
    }

    generateIssueRow(item) {
        const labels = this.generateLabelsHTML(item.labels || []);
        const assignee = this.generateAssigneeHTML(item.assignee);
        // Extract issue author similar to PRs
        let authorLogin = '';
        if (item.user_login) {
            authorLogin = item.user_login;
        } else if (item.user) {
            authorLogin = (typeof item.user === 'string') ? item.user : (item.user && item.user.login ? item.user.login : '');
        } else if (item.author) {
            authorLogin = (typeof item.author === 'string') ? item.author : (item.author && item.author.login ? item.author.login : '');
        }
    const createdProps = this.getDateCellProps(item.created_at);
    const updatedProps = this.getDateCellProps(item.updated_at);

        const modalData = {
            repo: item.repository || item.repo,
            number: item.number,
            title: item.title,
            htmlUrl: item.html_url,
            body: item.body || '',
            triage: item.triage || '0',
            priority: item.priority || '0',
            comments: item.comments || '',
            assignees: item.assignee ? [item.assignee] : [],
            labels: Array.isArray(item.labels) ? item.labels : (item.labels ? JSON.parse(item.labels) : []),
            mentions: item.mentions || []
        };

        return `
    <tr data-repo="${this.escapeHtml(item.repository || item.repo || '')}"
            data-modal-data='${JSON.stringify(modalData).replace(/'/g, "&apos;")}'
            data-number="${item.number}"
            data-title="${this.escapeHtml(item.title)}"
            data-assignee="${assignee ? this.escapeHtml(assignee) : ''}"
            data-created="${item.created_at}"
            data-updated="${item.updated_at}"
            data-state="${item.state || ''}"
            data-triage="${item.triage || '0'}"
            data-priority="${item.priority || '0'}">
            <td><a href="${item.html_url}" target="_blank">#${item.number}</a></td>
            <td><a href="#" class="open-modal"><strong>${this.escapeHtml(item.title)}</strong></a>${item.state === 'closed' ? '<span class="badge badge-danger ml-2">Closed</span>' : ''}</td>
            <td>${labels}</td>
            <td>${authorLogin ? `<a href="https://github.com/${authorLogin}" target="_blank">@${authorLogin}</a>` : '<span class="text-muted">Unknown</span>'}</td>
            <td>${assignee}</td>
        <td class="date-cell ${createdProps.cls}" title="${this.escapeHtml(createdProps.title)}">${this.escapeHtml(createdProps.text)}</td>
        <td class="date-cell ${updatedProps.cls}" title="${this.escapeHtml(updatedProps.title)}">${this.escapeHtml(updatedProps.text)}</td>
        </tr>`;
    }

    generatePRRow(item) {
    const createdProps = this.getDateCellProps(item.created_at);
    const updatedProps = this.getDateCellProps(item.updated_at);

        // Prefer explicit user_login from sync service; fallback to user object/string or author
        let authorLogin = '';
        if (item.user_login) {
            authorLogin = item.user_login;
        } else if (item.user) {
            authorLogin = (typeof item.user === 'string') ? item.user : (item.user && item.user.login ? item.user.login : '');
        } else if (item.author) {
            authorLogin = (typeof item.author === 'string') ? item.author : (item.author && item.author.login ? item.author.login : '');
        }

    // Map reviewers to array of login strings (requested_reviewers preferred)
    const reviewersRaw = Array.isArray(item.requested_reviewers) ? item.requested_reviewers
                  : (Array.isArray(item.reviewers) ? item.reviewers : []);
    const reviewers = reviewersRaw.map(r => typeof r === 'string' ? r : (r && r.login ? r.login : '')).filter(Boolean);

    // Assignees may be array of objects with login/html_url
    const assigneesRaw = Array.isArray(item.assignees) ? item.assignees : [];

        const labelsHTML = this.generateLabelsHTML(item.labels || []);
    const reviewersHTML = this.generateUserBadgesHTML(reviewers);
    const assigneesHTML = this.generateUserBadgesHTML(assigneesRaw);

        const modalData = {
            dataType: 'prs',
            repo: item.repository || item.repo,
            number: item.number,
            title: item.title,
            htmlUrl: item.html_url,
            body: item.body || '',
            author: authorLogin,
            reviewers: reviewers,
            status: item.state,
            draft: !!item.draft,
            merged: !!item.merged,
            baseRef: item.base_ref || '',
            headRef: item.head_ref || '',
            labels: Array.isArray(item.labels) ? item.labels : (item.labels ? JSON.parse(item.labels) : []),
            mentions: item.mentions || [],
            comments: item.comments || ''
        };

        return `
    <tr data-repo="${this.escapeHtml(item.repository || item.repo || '')}"
            data-modal-data='${JSON.stringify(modalData).replace(/'/g, "&apos;")}'
            data-number="${item.number}"
            data-title="${this.escapeHtml(item.title)}"
            data-created="${item.created_at}"
            data-updated="${item.updated_at}"
            data-state="${item.state || ''}">
            <td><a href="${item.html_url}" target="_blank">#${item.number}</a></td>
            <td><a href="#" class="open-modal"><strong>${this.escapeHtml(item.title)}</strong></a></td>
            <td>${labelsHTML || '<span class="text-muted">None</span>'}</td>
            <td>${authorLogin ? `<a href="https://github.com/${authorLogin}" target="_blank">@${authorLogin}</a>` : '<span class="text-muted">Unknown</span>'}</td>
            <td>${reviewersHTML || '<span class="text-muted">None</span>'}</td>
            <td>${assigneesHTML || '<span class="text-muted">None</span>'}</td>
            <td class="date-cell ${createdProps.cls}" title="${this.escapeHtml(createdProps.title)}">${this.escapeHtml(createdProps.text)}</td>
            <td class="date-cell ${updatedProps.cls}" title="${this.escapeHtml(updatedProps.title)}">${this.escapeHtml(updatedProps.text)}</td>
        </tr>`;
    }

    // Weeks-based date badge helpers
    getWeeksSince(dateStr) {
        if (!dateStr) return null;
        const now = new Date();
        const then = new Date(dateStr);
        const diffMs = now - then;
        const weeks = Math.floor(diffMs / (1000 * 60 * 60 * 24 * 7));
        return weeks < 0 ? 0 : weeks; // clamp
    }

    getDateBadgeClass(weeks) {
        if (weeks === null || weeks === undefined) return 'date-unknown';
        if (weeks <= 1) return 'date-fresh';
        if (weeks <= 4) return 'date-warm';
        if (weeks <= 12) return 'date-stale';
        return 'date-old';
    }

    // For coloring the entire cell (without a badge)
    getDateCellProps(dateStr) {
        if (!dateStr) {
            return { cls: 'date-unknown', text: '—', title: '' };
        }
        const weeks = this.getWeeksSince(dateStr);
        const cls = this.getDateBadgeClass(weeks);
        const formatted = this.formatDate(dateStr);
        const title = isNaN(weeks) ? formatted : `${formatted} (${weeks}w)`;
        return { cls, text: formatted, title };
    }

    renderDateBadge(dateStr) {
        if (!dateStr) return '<span class="text-muted">—</span>';
        const weeks = this.getWeeksSince(dateStr);
        const cls = this.getDateBadgeClass(weeks);
        const label = isNaN(weeks) ? '—' : `${weeks}w`;
        const formatted = this.formatDate(dateStr);
        return `<span class="date-badge ${cls}" title="${formatted}">${label}</span> <span class="text-muted">${formatted}</span>`;
    }

    generateUserBadgesHTML(users) {
        if (!users || users.length === 0) return '';
        try {
            // Normalize to list of {login, html_url}
            const norm = users.map(u => {
                if (typeof u === 'string') {
                    return { login: u, html_url: `https://github.com/${u}` };
                } else if (u && typeof u === 'object') {
                    const login = u.login || '';
                    const url = u.html_url || (login ? `https://github.com/${login}` : '#');
                    return { login, html_url: url };
                }
                return null;
            }).filter(Boolean);

            // Limit to first 3 and show "+N" for the rest
            const visible = norm.slice(0, 3);
            const remaining = norm.length - visible.length;
            const badges = visible.map(u => 
                `<a href="${u.html_url}" target="_blank" class="badge badge-info mr-1">@${this.escapeHtml(u.login)}</a>`
            ).join('');
            return remaining > 0 ? `${badges}<span class="badge badge-light">+${remaining} more</span>` : badges;
        } catch (e) {
            return '';
        }
    }
    
    generateLabelsHTML(labels) {
        if (!labels) return '';
        
        try {
            // Handle both array and string formats
            const labelsArray = Array.isArray(labels) ? labels : JSON.parse(labels);
            
            if (labelsArray.length === 0) return '';
            
            return labelsArray.map(label => {
                // Handle both string labels and object labels
                let labelName, labelColor;
                
                if (typeof label === 'string') {
                    labelName = label;
                    labelColor = this.getLabelColor(label); // Generate color based on label name
                } else if (label && typeof label === 'object') {
                    labelName = label.name || label;
                    labelColor = label.color || this.getLabelColor(labelName);
                } else {
                    return ''; // Skip invalid labels
                }
                
                return `<span class="badge badge-secondary" style="background-color: #${labelColor}; color: ${this.getContrastColor(labelColor)};">
                    ${this.escapeHtml(labelName)}
                </span>`;
            }).join(' ');
        } catch (e) {
            console.warn('Error parsing labels:', e, labels);
            return '';
        }
    }
    
    // Generate a consistent color for a label name
    getLabelColor(labelName) {
        if (!labelName) return 'cccccc';
        
        // Simple hash function to generate consistent colors
        let hash = 0;
        for (let i = 0; i < labelName.length; i++) {
            hash = labelName.charCodeAt(i) + ((hash << 5) - hash);
        }
        
        // Convert to hex color (avoid too dark colors)
        const color = ((hash & 0x00FFFFFF) | 0x808080).toString(16).toUpperCase();
        return color.padStart(6, '0');
    }
    
    generateAssigneeHTML(assignee) {
        if (!assignee) return '<span class="text-muted">Unassigned</span>';
        
        try {
            // Handle both object and string formats
            if (typeof assignee === 'string') {
                // Could be a simple login string or JSON
                if (assignee.startsWith('{') || assignee.startsWith('[')) {
                    const assigneeData = JSON.parse(assignee);
                    if (Array.isArray(assigneeData) && assigneeData.length > 0) {
                        return `<a href="${assigneeData[0].html_url}" target="_blank">${this.escapeHtml(assigneeData[0].login)}</a>`;
                    } else if (assigneeData.login) {
                        return `<a href="${assigneeData.html_url}" target="_blank">${this.escapeHtml(assigneeData.login)}</a>`;
                    }
                } else {
                    // Simple string login
                    return this.escapeHtml(assignee);
                }
            } else if (assignee.login) {
                // Direct object
                return `<a href="${assignee.html_url}" target="_blank">${this.escapeHtml(assignee.login)}</a>`;
            }
        } catch (e) {
            console.warn('Error parsing assignee:', e, assignee);
        }
        
        return this.escapeHtml(String(assignee));
    }
    
    formatDate(dateStr) {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString();
    }
    
    getContrastColor(hexColor) {
        // Simple contrast color calculation
        const r = parseInt(hexColor.substr(0, 2), 16);
        const g = parseInt(hexColor.substr(2, 2), 16);
        const b = parseInt(hexColor.substr(4, 2), 16);
        const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return luminance > 0.5 ? '#000000' : '#ffffff';
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    updateNavigation() {
        // Build navbar dynamically based on actual repositories from API
        if (!this.state.repositories) {
            console.log('updateNavigation: No repositories data available');
            return;
        }
        
        console.log('updateNavigation: Building navbar from', this.state.repositories.length, 'repositories');
        
        // Group repositories by category and calculate what categories we actually have
        const categoriesMap = new Map();
        
        this.state.repositories.forEach(repo => {
            const category = repo.main_category || repo.sdk_type;
            if (!categoriesMap.has(category)) {
                categoriesMap.set(category, {
                    repositories: [],
                    count: 0
                });
            }
            categoriesMap.get(category).repositories.push(repo);
            categoriesMap.get(category).count += repo.count;
        });
        
        console.log('Categories found:', Array.from(categoriesMap.keys()));
        
        // Build navbar dynamically
        this.buildDynamicNavbar(categoriesMap);
    }
    
    updateNavbarCount(elementId, count) {
        // This method is now obsolete since we build counts dynamically
        console.log(`Legacy updateNavbarCount called for ${elementId} with count ${count}`);
    }
    
    buildDynamicNavbar(categoriesMap) {
        // Find the navbar nav element where we'll insert the dynamic dropdowns
        const navbarNav = document.querySelector('#navbarNav .navbar-nav.mr-auto');
        if (!navbarNav) {
            console.error('Could not find navbar navigation element');
            return;
        }
        
        // Clear existing dynamic dropdowns (keep only the brand)
        navbarNav.innerHTML = '';
        
        // Category display config
        const categoryConfig = {
            'nodejs': { icon: 'fab fa-node-js', label: 'Node.js' },
            'python': { icon: 'fab fa-python', label: 'Python' },
            'dotnet': { icon: 'fab fa-microsoft', label: '.NET' },
            'browser': { icon: 'fab fa-js-square', label: 'Browser JS' },
            'javascript': { icon: 'fab fa-js-square', label: 'Browser JS' },
            'java': { icon: 'fab fa-java', label: 'Java' },
            'react': { icon: 'fab fa-react', label: 'React' },
            'other': { icon: 'fas fa-code', label: 'Other' }
        };
        
        // Build dropdown for each category that has repositories
        Array.from(categoriesMap.entries()).forEach(([category, data]) => {
            const config = categoryConfig[category] || categoryConfig['other'];
            const dropdownId = `${category}-dropdown-menu`;
            
            const dropdownHTML = `
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="${category}Dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="${config.icon} language-icon"></i>${config.label}
                        <span class="badge badge-count" id="navbar-${category}-count">${data.count}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="${category}Dropdown" id="${dropdownId}">
                        ${this.buildDropdownContent(data.repositories)}
                    </div>
                </li>
            `;
            
            navbarNav.insertAdjacentHTML('beforeend', dropdownHTML);
        });
        
        console.log('Dynamic navbar built with', categoriesMap.size, 'categories');
        
        // Re-initialize Bootstrap dropdowns
        this.initializeBootstrapDropdowns();
    }
    
    buildDropdownContent(repositories) {
        if (!repositories || repositories.length === 0) {
            return '<span class="dropdown-item-text text-muted">No repositories</span>';
        }
        
        return repositories.map(repo => {
            const isActive = repo.name === this.state.selectedRepo ? 'active' : '';
            const countBadge = repo.count > 0 ? 
                `<span class="badge badge-light ml-2">${repo.count}</span>` : 
                `<span class="badge badge-secondary ml-2">0</span>`;
            
            return `<a class="dropdown-item ${isActive}" href="#" onclick="dashboardSPA.selectRepository('${repo.name}'); return false;">
                ${repo.display_name} ${countBadge}
            </a>`;
        }).join('');
    }
    
    initializeBootstrapDropdowns() {
        // Initialize or re-initialize Bootstrap dropdowns after dynamic content is added
        try {
            // Use jQuery to initialize dropdowns (Bootstrap 4 syntax)
            if (typeof $ !== 'undefined') {
                const dropdownCount = $('.dropdown-toggle').length;
                console.log('Found', dropdownCount, 'dropdown toggles to initialize');
                
                // Dispose existing dropdown instances first
                $('.dropdown-toggle').dropdown('dispose');
                // Re-initialize dropdowns
                $('.dropdown-toggle').dropdown();
                console.log('Bootstrap 4 dropdowns initialized via jQuery');
            } else {
                console.warn('jQuery not available - cannot initialize Bootstrap 4 dropdowns');
            }
        } catch (error) {
            console.warn('Could not initialize Bootstrap dropdowns:', error);
        }
    }
    
    updateVisibility() {
        const hasRepo = this.state.selectedRepo !== '';
        
        console.log('updateVisibility called with:', {
            hasRepo,
            selectedRepo: this.state.selectedRepo,
            repositoriesLoaded: this.state.repositories.length
        });
        
        // Show/hide intro page - show when no specific repo is selected
        const introPage = document.getElementById('intro-page');
        if (introPage) {
            if (hasRepo) {
                introPage.style.display = 'none';
                console.log('Intro page hidden');
            } else {
                introPage.style.display = 'block';
                console.log('Intro page shown');
            }
        }
        
        // Show/hide empty state
        const emptyState = document.getElementById('empty-state');
        if (emptyState) {
            emptyState.style.display = 'none';
        }
        
        // Show/hide repository sections based on selection
        const allSections = document.querySelectorAll('.repository-section');
        console.log('Found repository sections:', allSections.length);
        
        if (hasRepo) {
            // Show only the selected repository section
            let foundMatchingSection = false;
            allSections.forEach(section => {
                const sectionRepo = section.getAttribute('data-repo');
                const shouldShow = sectionRepo === this.state.selectedRepo;
                section.style.display = shouldShow ? 'block' : 'none';
                
                // Also handle the 'active' class required by CSS
                if (shouldShow) {
                    section.classList.add('active');
                } else {
                    section.classList.remove('active');
                }
                
                console.log(`Section ${sectionRepo}: display = ${section.style.display}, shouldShow = ${shouldShow}, hasActive = ${section.classList.contains('active')}`);
                if (shouldShow) {
                    foundMatchingSection = true;
                }
            });
            
            if (!foundMatchingSection) {
                console.warn('No matching repository section found for:', this.state.selectedRepo);
                console.log('Available sections:', Array.from(allSections).map(s => s.getAttribute('data-repo')));
            }
        } else {
            // Hide all repository sections when no specific repo is selected - show only intro page
            allSections.forEach(section => {
                section.style.display = 'none'; // Hide all sections
                section.classList.remove('active'); // Remove active class
                console.log(`Section ${section.getAttribute('data-repo')}: hidden (no specific selection)`);
            });
        }
    }
    
    initializeRepositorySections() {
        // Initialize pagination, sorting, and other functionality for new sections
        // This integrates with existing dashboard.js functionality
        this.state.repositories.forEach(repo => {
            if (repo.count > 0) {
                // Use setTimeout to ensure DOM elements are ready
                setTimeout(() => {
                    // Initialize pagination for this repository
                    if (typeof initializePagination === 'function') {
                        const pageInput = document.getElementById('page-input-' + repo.id);
                        if (pageInput) {
                            initializePagination(repo.id, repo.count);
                        }
                    }
                    
                    // Initialize sorting for this repository  
                    if (typeof initializeSorting === 'function') {
                        initializeSorting(repo.id);
                    }
                    
                    // Show first page
                    if (typeof showPage === 'function') {
                        showPage(repo.id, 1);
                    }
                }, 10); // Small delay to ensure DOM is updated
            }
        });
    }
    
    initializeTableForRepository(repoId, items) {
        // Initialize pagination for the table
        setTimeout(() => {
            console.log('Initializing table for repo:', repoId, 'with', items.length, 'items');
            
            // Initialize pagination
            initializePagination(repoId, items.length);
            
            // Initialize sorting for the table
            initializeSorting(repoId);
            
            // Show first page
            showPage(repoId, 1);
            
            // Set up search functionality
            const searchBox = document.getElementById(`search-${repoId}`);
            if (searchBox) {
                searchBox.addEventListener('input', (e) => {
                    filterTable(repoId, e.target.value);
                });
            }
        }, 100); // Increased delay to ensure DOM is fully ready
    }
    
    setDataType(dataType) {
        if (dataType !== this.state.dataType) {
            this.state.dataType = dataType;
            this.updateURL();
            this.updateDataTypeToggle(); // Update button UI states
            this.loadDashboardData();
        }
    }
    
    setShowState(showState) {
        if (showState !== this.state.showState) {
            this.state.showState = showState;
            this.updateURL();
            this.updateGlobalStateToggle();
            this.loadDashboardData();
        }
    }
    
    setSelectedRepo(repo) {
        if (repo !== this.state.selectedRepo) {
            this.state.selectedRepo = repo;
            this.updateURL();
            this.updateVisibility();
            
            // Load dashboard data when a specific repository is selected
            if (repo && repo !== 'all' && repo !== '') {
                console.log('Repository selected, loading dashboard data for:', repo);
                this.loadDashboardData();
            } else {
                console.log('No specific repository selected, clearing dashboard data');
                // Clear the repositories container when no specific repo is selected
                const contentContainer = document.getElementById('repositories-container');
                if (contentContainer) {
                    contentContainer.innerHTML = '';
                }
            }
        }
    }
    
    updateURL() {
        // Don't update URL during initial state application to prevent conflicts
        if (this.isInitializing) {
            console.log('Skipping URL update during initialization');
            return;
        }
        
        const params = new URLSearchParams();
        
        if (this.state.dataType !== 'issues') {
            params.set('type', this.state.dataType);
        }
        if (this.state.showState !== 'open') {
            params.set('state', this.state.showState);
        }
        if (this.state.selectedRepo) {
            params.set('repo', this.state.selectedRepo);
        }
        
        const newURL = `${window.location.pathname}${params.toString() ? '?' + params.toString() : ''}`;
        window.history.pushState({ spa: true }, '', newURL);
    }
    
    updateURLFromState() {
        // Only update URL if we're not in the initial loading phase
        if (this.state.repositories && this.state.repositories.length > 0) {
            this.updateURL();
        }
    }
    
    handlePopState(e) {
        if (e.state && e.state.spa) {
            // Handle browser back/forward
            this.loadInitialState();
            this.loadDashboardData();
        }
    }
    
    setLoading(loading) {
        this.state.isLoading = loading;
        
        // Show/hide loading indicator
        const existingLoader = document.querySelector('.spa-loading');
        if (loading && !existingLoader) {
            const loader = document.createElement('div');
            loader.className = 'spa-loading';
            loader.innerHTML = `
                <div class="d-flex justify-content-center align-items-center" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,0.8); z-index: 9999;">
                    <div class="spinner-border" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            `;
            document.body.appendChild(loader);
        } else if (!loading && existingLoader) {
            existingLoader.remove();
        }
    }
    
    showError(message) {
        // Show error message to user
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger alert-dismissible fade show';
        errorDiv.innerHTML = `
            ${message}
            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        `;
        
        const container = document.querySelector('.main-container');
        if (container) {
            container.insertBefore(errorDiv, container.firstChild);
            
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                if (errorDiv.parentNode) {
                    errorDiv.remove();
                }
            }, 5000);
        }
    }

    showApiError(message) {
        // Remove any existing API error banner
        this.hideApiError();
        
        // Create a persistent API error banner
        const errorBanner = document.createElement('div');
        errorBanner.id = 'api-error-banner';
        errorBanner.className = 'alert alert-warning alert-dismissible mb-3';
        errorBanner.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <div class="flex-grow-1">
                    <strong>API Service Unavailable:</strong> ${message}
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        const container = document.querySelector('.main-container') || document.querySelector('.container-fluid');
        if (container) {
            container.insertBefore(errorBanner, container.firstChild);
        }
    }

    hideApiError() {
        // Remove the API error banner if it exists
        const errorBanner = document.getElementById('api-error-banner');
        if (errorBanner) {
            errorBanner.remove();
        }
    }

    updateElementText(id, text) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = text;
        }
    }
    
    // Public methods for external integration
    toggleDataType(dataType) {
        this.setDataType(dataType);
    }
    
    selectRepository(repo) {
        this.setSelectedRepo(repo);
    }
    
    changeState(state) {
        this.setShowState(state);
    }
    
    refresh() {
        // Clear cache and reload data
        this.state.cache.clear();
        this.loadDashboardData();
    }
}

// Global SPA instance
let dashboardSPA;

// Initialize SPA when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Set a flag to indicate SPA is taking control
    window.spaActive = true;
    
    // Override the original dashboard.js initialization to prevent conflicts
    window.initializePageFromUrl = function() {
        console.log('Dashboard.js initializePageFromUrl disabled - SPA is active');
    };
    
    dashboardSPA = new DashboardSPA();
    window.dashboardSPA = dashboardSPA; // Make it available globally
    
    // Initialize Bootstrap dropdowns on page load
    if (dashboardSPA && dashboardSPA.initializeBootstrapDropdowns) {
        setTimeout(() => {
            dashboardSPA.initializeBootstrapDropdowns();
        }, 100); // Small delay to ensure DOM is fully ready
    }
});

// Global functions for backward compatibility with existing code
function toggleDataType(dataType) {
    if (dashboardSPA) {
        dashboardSPA.toggleDataType(dataType);
    }
}

function clearRepoSelection() {
    if (dashboardSPA) {
        // Clear all URL parameters and return to home page default state
        dashboardSPA.state.selectedRepo = '';
        dashboardSPA.state.dataType = 'issues';
        dashboardSPA.state.showState = 'open';
        
        // Clear URL parameters by navigating to clean URL
        window.history.pushState({ spa: true }, '', window.location.pathname);
        
        // Reload data with default parameters and update UI
        dashboardSPA.loadDashboardData();
        dashboardSPA.updateDataTypeToggle();
        dashboardSPA.updateVisibility();
    }
}

function testRepoSelection(repo) {
    console.log('testRepoSelection called with:', repo);
    if (dashboardSPA) {
        dashboardSPA.selectRepository(repo);
    }
}

// Export for use in other scripts
window.DashboardSPA = DashboardSPA;
window.testRepoSelection = testRepoSelection;

// Handle home navigation - works on both SPA and non-SPA pages
function handleHomeNavigation() {
    // If we're on the dashboard page and have SPA functionality, use SPA navigation
    if (window.location.pathname === '/' && typeof clearRepoSelection === 'function') {
        clearRepoSelection();
        return false; // Prevent default href navigation
    }
    
    // For other pages or if SPA isn't available, navigate to home
    window.location.href = '/';
    return false;
}

// Export the navigation function
window.handleHomeNavigation = handleHomeNavigation;

// Global state for pagination and sorting (required by navigation functions)
const pageStates = {};
const itemsPerPage = 10;
const sortStates = {};

// Global navigation functions required by table controls
function sortTable(repoId, column) {
    initializeSorting(repoId);
    const sortState = sortStates[repoId];
    const table = document.getElementById('table-' + repoId);
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    // Toggle direction if same column, else reset to ascending
    if (sortState.column === column) {
        sortState.direction = sortState.direction === 'asc' ? 'desc' : 'asc';
    } else {
        sortState.direction = 'asc';
    }
    sortState.column = column;
    
    // Update header styling
    updateSortHeaders(repoId);
    
    // Sort rows based on column and direction
    rows.sort((a, b) => {
        let aVal = getSortValue(a, column);
        let bVal = getSortValue(b, column);
        
        // Handle different data types
        if (column === 'number' || column === 'priority' || column === 'triage') {
            aVal = parseInt(aVal) || 0;
            bVal = parseInt(bVal) || 0;
        } else if (column === 'created' || column === 'updated') {
            aVal = new Date(aVal);
            bVal = new Date(bVal);
        }
        
        let result;
        if (aVal < bVal) result = -1;
        else if (aVal > bVal) result = 1;
        else result = 0;
        
        return sortState.direction === 'desc' ? -result : result;
    });
    
    // Re-append sorted rows
    rows.forEach(row => tbody.appendChild(row));
    
    // Update pagination after sorting
    const state = pageStates[repoId];
    if (state) {
        showPage(repoId, state.currentPage);
    }
}

function getSortValue(row, column) {
    switch (column) {
        case 'number':
            return row.dataset.number;
        case 'title':
            return row.dataset.title;
        case 'assignee':
            return row.dataset.assignee;
        case 'created':
            return row.dataset.created;
        case 'updated':
            return row.dataset.updated;
        case 'triage':
            return row.dataset.triage;
        case 'priority':
            return row.dataset.priority;
        default:
            return '';
    }
}

function updateSortHeaders(repoId) {
    const table = document.getElementById('table-' + repoId);
    const headers = table.querySelectorAll('th.sortable');
    const sortState = sortStates[repoId];
    
    headers.forEach(header => {
        header.classList.remove('sort-asc', 'sort-desc');
        if (header.dataset.column === sortState.column) {
            header.classList.add('sort-' + sortState.direction);
        }
    });
}

function initializePagination(repoId, totalItems) {
    console.log('initializePagination:', repoId, 'totalItems:', totalItems);
    
    if (!pageStates[repoId]) {
        pageStates[repoId] = {
            currentPage: 1,
            totalItems: totalItems,
            totalPages: Math.ceil(totalItems / itemsPerPage),
            filteredItems: totalItems
        };
    }
    initializeSorting(repoId);
    
    // Ensure all rows are visible initially, then apply pagination
    const table = document.getElementById('table-' + repoId);
    if (table) {
        const rows = Array.from(table.getElementsByTagName('tr')).slice(1); // Skip header
        rows.forEach(row => {
            row.classList.remove('pagination-hidden');
            row.style.display = ''; // Reset any inline styles
        });
    }
    
    // For performance, hide all rows initially except first page
    setTimeout(() => {
        showPage(repoId, 1);
    }, 50);
}

function showPage(repoId, page) {
    const table = document.getElementById('table-' + repoId);
    
    if (!table) {
        console.log('Table not found for repo:', repoId);
        return;
    }
    
    const rows = Array.from(table.getElementsByTagName('tr')).slice(1); // Skip header
    const state = pageStates[repoId];
    
    if (!state) {
        console.log('Page state not found for repo:', repoId);
        return;
    }
    
    console.log('showPage:', repoId, 'page:', page, 'total rows:', rows.length);
    
    // Filter visible rows first (not previously hidden by search)
    const visibleRows = rows.filter(row => row.style.display !== 'none');
    state.filteredItems = visibleRows.length;
    state.totalPages = Math.ceil(state.filteredItems / itemsPerPage);
    
    // Ensure page is within bounds
    page = Math.max(1, Math.min(page, state.totalPages));
    state.currentPage = page;
    
    // Hide all rows first
    rows.forEach(row => {
        if (row.style.display !== 'none') {
            row.classList.add('pagination-hidden');
        }
    });
    
    // Show only current page rows
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    
    const rowsToShow = visibleRows.slice(startIndex, endIndex);
    console.log('Showing rows:', startIndex, 'to', endIndex, 'count:', rowsToShow.length);
    console.log('Rows to show:', rowsToShow.map(r => r.textContent.substring(0, 50)));
    
    rowsToShow.forEach((row, index) => {
        row.classList.remove('pagination-hidden');
        console.log('Made visible row', startIndex + index, ':', row.textContent.substring(0, 50));
    });
    
    // Only update pagination controls if they exist
    try {
        updatePaginationControls(repoId);
    } catch (error) {
        console.warn('Could not update pagination controls:', error);
    }
}

function updatePaginationControls(repoId) {
    const state = pageStates[repoId];
    const controls = document.getElementById('pagination-' + repoId);
    
    if (!controls) {
        console.log('Pagination controls not found for repo:', repoId);
        return;
    }
    
    if (state.totalPages <= 1) {
        controls.style.display = 'none';
        return;
    } else {
        controls.style.display = 'flex';
    }
    
    // Update info
    const pageInfoElement = document.getElementById('page-info-' + repoId);
    if (pageInfoElement) {
        const startItem = (state.currentPage - 1) * itemsPerPage + 1;
        const endItem = Math.min(state.currentPage * itemsPerPage, state.filteredItems);
        pageInfoElement.textContent = 
            `Showing ${startItem}-${endItem} of ${state.filteredItems} items`;
    }
    
    // Update buttons
    const prevBtn = document.getElementById('prev-btn-' + repoId);
    const nextBtn = document.getElementById('next-btn-' + repoId);
    
    if (prevBtn) {
        prevBtn.disabled = state.currentPage === 1;
    }
    if (nextBtn) {
        nextBtn.disabled = state.currentPage === state.totalPages;
    }
    
    // Update page input
    const pageInput = document.getElementById('page-input-' + repoId);
    if (pageInput) {
        pageInput.value = state.currentPage;
        pageInput.max = state.totalPages;
    }
    
    // Update page counter
    const pageCounter = document.getElementById('page-counter-' + repoId);
    if (pageCounter) {
        pageCounter.textContent = state.totalPages;
    }
}

function goToPage(repoId, page) {
    const state = pageStates[repoId];
    if (!state) return;
    
    const pageNum = parseInt(page);
    if (isNaN(pageNum) || pageNum < 1 || pageNum > state.totalPages) {
        // Reset input to current page if invalid
        const pageInput = document.getElementById('page-input-' + repoId);
        if (pageInput) {
            pageInput.value = state.currentPage;
        }
        return;
    }
    
    showPage(repoId, pageNum);
}

function nextPage(repoId) {
    const state = pageStates[repoId];
    if (state && state.currentPage < state.totalPages) {
        showPage(repoId, state.currentPage + 1);
    }
}

function prevPage(repoId) {
    const state = pageStates[repoId];
    if (state && state.currentPage > 1) {
        showPage(repoId, state.currentPage - 1);
    }
}

function filterTable(repoId, searchTerm) {
    const table = document.getElementById('table-' + repoId);
    if (!table) return;
    
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const text = row.textContent.toLowerCase();
        if (text.includes(searchTerm.toLowerCase())) {
            row.style.display = '';
            row.classList.remove('pagination-hidden');
        } else {
            row.style.display = 'none';
            row.classList.add('pagination-hidden');
        }
    }
    
    // Reset to page 1 after filtering
    showPage(repoId, 1);
}

function initializeSorting(repoId) {
    if (!sortStates[repoId]) {
        sortStates[repoId] = {
            column: null,
            direction: 'asc'
        };
    }
}

// Make functions globally available
window.sortTable = sortTable;
window.goToPage = goToPage;
window.nextPage = nextPage;
window.prevPage = prevPage;
window.filterTable = filterTable;
window.initializePagination = initializePagination;
window.initializeSorting = initializeSorting;
window.showPage = showPage;

// Global function for opening issue modal from table row data
function openIssueModalFromData(row) {
    try {
        let modalData;
        try {
            modalData = JSON.parse(row.getAttribute('data-modal-data'));
        } catch (jsonError) {
            console.warn('Failed to parse modal data JSON, falling back to row attributes:', jsonError);
            // Fallback: extract data from row attributes directly
            modalData = {
                repo: row.getAttribute('data-repo') || '',
                number: row.getAttribute('data-number') || '',
                title: row.getAttribute('data-title') || '',
                htmlUrl: row.querySelector('a[href*="github.com"]')?.href || '',
                body: '',
                labels: [],
                assignees: [],
                comments: ''
            };
        }
        
        // Populate modal using the existing HTML template
        populateModal(modalData);
        
        // Show modal
        const modal = document.getElementById('issueModal');
        if (typeof $ !== 'undefined') {
            $(modal).modal('show');
        } else {
            modal.style.display = 'block';
            modal.classList.add('show');
            
            // Add backdrop
            const backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop fade show';
            document.body.appendChild(backdrop);
            
            // Close modal on backdrop click
            backdrop.addEventListener('click', () => {
                modal.style.display = 'none';
                modal.classList.remove('show');
                backdrop.remove();
            });
            
            // Close modal on close button click
            const closeButtons = modal.querySelectorAll('[data-dismiss="modal"]');
            closeButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    modal.style.display = 'none';
                    modal.classList.remove('show');
                    backdrop.remove();
                });
            });
        }
        
    } catch (error) {
        console.error('Error opening modal:', error);
        // Show a simple alert as fallback
        alert('Unable to load issue details. Please try again.');
    }
}

// Function to populate modal template with data
function populateModal(modalData) {
    // Sanitize strings to prevent XSS
    const sanitize = (str) => {
        if (!str) return '';
        return String(str).replace(/[<>&"']/g, (match) => {
            const escape = {
                '<': '&lt;',
                '>': '&gt;',
                '&': '&amp;',
                '"': '&quot;',
                "'": '&#39;'
            };
            return escape[match];
        });
    };
    
    // Set modal type and number
    const modalType = modalData.dataType === 'prs' ? 'Pull Request' : 'Issue';
    document.getElementById('modal-type').textContent = modalType;
    document.getElementById('modal-number').textContent = sanitize(modalData.number);
    
    // Set title
    document.getElementById('modal-title-text').innerHTML = `<strong>${sanitize(modalData.title)}</strong>`;
    
    // Set repository
    document.getElementById('modal-repo-name').textContent = sanitize(modalData.repo);
    document.getElementById('modal-repo-link').href = `https://github.com/${sanitize(modalData.repo)}`;
    
    // Set GitHub URL
    if (modalData.htmlUrl) {
        document.getElementById('modal-url-text').textContent = sanitize(modalData.htmlUrl);
        document.getElementById('modal-url-link').href = sanitize(modalData.htmlUrl);
        document.getElementById('modal-github-link').href = sanitize(modalData.htmlUrl);
    }
    
    // Set description (conditionally show)
    if (modalData.body) {
        document.getElementById('modal-description').innerHTML = sanitize(modalData.body).replace(/\n/g, '<br>');
        document.getElementById('modal-description-section').style.display = 'block';
    } else {
        document.getElementById('modal-description-section').style.display = 'none';
    }
    
    // Set labels (conditionally show)
    if (modalData.labels && modalData.labels.length > 0) {
        const labelsHTML = modalData.labels.map(l => 
            `<span class="badge badge-secondary">${sanitize(l.name || l)}</span>`
        ).join(' ');
        document.getElementById('modal-labels').innerHTML = labelsHTML;
        document.getElementById('modal-labels-section').style.display = 'block';
    } else {
        document.getElementById('modal-labels-section').style.display = 'none';
    }
    
    // Set assignees (conditionally show)
    if (modalData.assignees && modalData.assignees.length > 0) {
        const assigneesText = modalData.assignees.map(a => `@${sanitize(a.login || a)}`).join(', ');
        document.getElementById('modal-assignees').textContent = assigneesText;
        document.getElementById('modal-assignees-section').style.display = 'block';
    } else {
        document.getElementById('modal-assignees-section').style.display = 'none';
    }
    
    // PR-specific fields
    if (modalData.dataType === 'prs') {
        // Set reviewers
        if (modalData.reviewers && modalData.reviewers.length > 0) {
            const reviewersText = modalData.reviewers.map(r => `@${sanitize(r)}`).join(', ');
            document.getElementById('modal-reviewers').textContent = reviewersText;
            document.getElementById('modal-reviewers-section').style.display = 'block';
        } else {
            document.getElementById('modal-reviewers-section').style.display = 'none';
        }
        
        // Set author
        if (modalData.author) {
            document.getElementById('modal-author').textContent = `@${sanitize(modalData.author)}`;
            document.getElementById('modal-author-section').style.display = 'block';
        } else {
            document.getElementById('modal-author-section').style.display = 'none';
        }
        
        // Set status
        if (modalData.status) {
            document.getElementById('modal-status').textContent = sanitize(modalData.status);
            document.getElementById('modal-status-section').style.display = 'block';
        } else {
            document.getElementById('modal-status-section').style.display = 'none';
        }
        
        // Set draft status
        if (modalData.draft !== undefined) {
            document.getElementById('modal-draft').textContent = modalData.draft ? 'Yes' : 'No';
            document.getElementById('modal-draft-section').style.display = 'block';
        } else {
            document.getElementById('modal-draft-section').style.display = 'none';
        }
        
        // Set branch info
        if (modalData.headRef || modalData.baseRef) {
            document.getElementById('modal-head-ref').textContent = sanitize(modalData.headRef || '');
            document.getElementById('modal-base-ref').textContent = sanitize(modalData.baseRef || '');
            document.getElementById('modal-branch-section').style.display = 'block';
        } else {
            document.getElementById('modal-branch-section').style.display = 'none';
        }
    } else {
        // Hide PR-specific sections for issues
        document.getElementById('modal-reviewers-section').style.display = 'none';
        document.getElementById('modal-author-section').style.display = 'none';
        document.getElementById('modal-status-section').style.display = 'none';
        document.getElementById('modal-draft-section').style.display = 'none';
        document.getElementById('modal-branch-section').style.display = 'none';
    }
    
    // Set comments (conditionally show)
    if (modalData.comments) {
        document.getElementById('modal-comments').textContent = sanitize(modalData.comments);
        document.getElementById('modal-comments-section').style.display = 'block';
    } else {
        document.getElementById('modal-comments-section').style.display = 'none';
    }
}

// Export for global access
window.openIssueModalFromData = openIssueModalFromData;
